package com.jarvis.offline

import android.Manifest
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.roundToInt

class MainActivity : android.app.Activity() {

    private lateinit var sr: SpeechRecognizer
    private var recognizerReady = false
    private lateinit var tts: TextToSpeech
    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var wakeBtn: Button
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random()
    private var torchOn = false

    // Veille vocale (mot magique)
    private var wakeMode = false
    private var wakeListening = false
    private var wakeTriggered = false

    private val jokes = listOf(
        "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon, ils tombent dans le bateau.",
        "Quel est le comble pour un électricien ? Ne pas être au courant.",
        "Pourquoi les poissons détestent l'ordinateur ? À cause du réseau.",
        "Que dit une imprimante dans l'eau ? J'ai papier !",
        "Pourquoi les fantômes sont-ils de si mauvais menteurs ? Parce qu'on peut les voir à travers.",
        "Que dit un mur à un autre mur ? On se retrouve au coin.",
        "Pourquoi les plages sont-elles mouillées ? Parce que les vagues les baignent, évidemment."
    )

    private fun pick(vararg options: String) = options[random.nextInt(options.size)]

    private val helpText =
        "Voici ce que je sais faire. Dites simplement Jarvis pour me réveiller quand la veille est activée. " +
        "Commandes : quelle heure est-il, quel jour sommes-nous, niveau de batterie, torche, vibre, " +
        "alarme 7 h 30, minuteur 5 minutes, appelle suivi d'un prénom, ouvre suivi d'une application, " +
        "volume plus, moins, maximum ou muet, Wi-Fi, Bluetooth, luminosité 50, calcule suivi d'un calcul, " +
        "note puis un texte, lis mes notes, pile ou face, lance un dé, dis une blague, musique, photo. " +
        "Et si internet est disponible : cherche suivi de quelque chose, sur Google, YouTube, Facebook, " +
        "Instagram, TikTok ou X, par exemple cherche des recettes de pâtes sur YouTube. " +
        "Vous pouvez aussi me demander qui est une personne ou c'est quoi un mot. " +
        "Je retiens votre prénom si vous me dites je m'appelle. Dites stop pour me faire taire."

    // ------------------------------------------------------------------ UI
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(0xFF0A0E14.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF00D4FF.toInt())
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Assistant vocal — hors ligne, enrichi en ligne"
            textSize = 14f
            setTextColor(0xFF8A9BA8.toInt())
            gravity = Gravity.CENTER
        }
        statusView = TextView(this).apply {
            text = "Initialisation..."
            textSize = 13f
            setTextColor(0xFF4CAF50.toInt())
            gravity = Gravity.CENTER
        }
        logView = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFE0E0E0.toInt())
        }
        val scroll = ScrollView(this).apply {
            addView(logView)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        val input = EditText(this).apply {
            hint = "...ou tapez une commande"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF8A9BA8.toInt())
        }
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val micBtn = Button(this).apply { text = "PARLER" }
        val sendBtn = Button(this).apply { text = "ENVOYER" }
        micBtn.setOnClickListener { startListening() }
        sendBtn.setOnClickListener {
            val txt = input.text.toString()
            if (txt.isNotBlank()) { input.setText(""); handle(txt) }
        }
        btnRow.addView(micBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnRow.addView(sendBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        wakeBtn = Button(this).apply { text = "VEILLE : OFF (mot magique)" }
        wakeBtn.setOnClickListener { toggleWakeMode() }
        root.addView(title)
        root.addView(sub)
        root.addView(statusView)
        root.addView(scroll)
        root.addView(input)
        root.addView(btnRow)
        root.addView(wakeBtn)
        setContentView(root)
    }

    // ------------------------------------------------------------------ Cycle de vie
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initTts()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            initRecognizer()
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE),
                42
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42) initRecognizer()
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeMode = false
        handler.removeCallbacksAndMessages(null)
        if (recognizerReady) sr.destroy()
        tts.stop()
        tts.shutdown()
    }

    // ------------------------------------------------------------------ TTS
    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.FRANCE
                tts.setSpeechRate(1.05f)
                runOnUiThread {
                    statusView.text = "Prêt — appuyez sur PARLER et parlez"
                    respond(pick(
                        "Systèmes en ligne. Bonjour, je suis Jarvis, votre assistant personnel. Dites aide pour découvrir mes commandes.",
                        "Tout est opérationnel. Bonjour ! Je suis Jarvis. Comment puis-je vous être utile ?",
                        "Démarrage terminé. Bonjour, Jarvis à votre service. Dites aide pour commencer."
                    ))
                }
            }
        }
    }

    // ------------------------------------------------------------------ Reconnaissance vocale
    private fun initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("Reconnaissance vocale indisponible sur cet appareil. Utilisez le clavier.")
            statusView.text = "Mode texte uniquement"
            return
        }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusView.text = if (wakeListening) "Veille active — dites « Jarvis »" else "Écoute... parlez"
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { if (!wakeListening) statusView.text = "Analyse..." }
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                if (!wakeListening || wakeTriggered) return
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val txt = matches?.joinToString(" ")?.norm() ?: return
                if (txt.contains("jarvis") || txt.contains("jarvie") || txt.contains("jarvi")) {
                    wakeTriggered = true
                    try { sr.stop() } catch (_: Exception) {}
                    notifyWake()
                    handler.postDelayed({ if (wakeMode) startListening() }, 400)
                }
            }

            override fun onError(error: Int) {
                if (wakeListening) { wakeListening = false; scheduleWakeRestart(); return }
                statusView.text = "Prêt"
                log("Je n'ai pas compris (erreur $error). Réessayez ou tapez votre commande.")
                if (wakeMode) scheduleWakeRestart()
            }

            override fun onResults(results: Bundle?) {
                statusView.text = "Prêt"
                if (wakeListening) { wakeListening = false; scheduleWakeRestart(); return }
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) handle(matches[0]) else respond(pick(
                    "Je n'ai rien entendu.", "Pouvez-vous répéter, s'il vous plaît ?", "Je n'ai pas saisi, désolé."
                ))
                if (wakeMode) scheduleWakeRestart()
            }
        })
        recognizerReady = true
    }

    private fun speechIntent(partial: Boolean) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "fr-FR")
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, partial)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }

    private fun startListening() {
        if (!recognizerReady) { log("Reconnaissance non disponible, tapez votre commande."); return }
        wakeListening = false
        try { sr.startListening(speechIntent(false)) } catch (e: Exception) { log("Erreur : ${e.message}") }
    }

    // ------------------------------------------------------------------ Veille vocale
    private fun toggleWakeMode() {
        wakeMode = !wakeMode
        wakeBtn.text = if (wakeMode) "VEILLE : ON — dites « Jarvis »" else "VEILLE : OFF (mot magique)"
        if (wakeMode) {
            respond("Veille vocale activée. Dites Jarvis pour me réveiller. Attention, cela consomme davantage de batterie.")
            startWakeListening()
        } else {
            wakeListening = false
            try { sr.cancel() } catch (_: Exception) {}
            respond("Veille vocale désactivée.")
        }
    }

    private fun startWakeListening() {
        if (!recognizerReady || !wakeMode) return
        wakeListening = true
        wakeTriggered = false
        try { sr.startListening(speechIntent(true)) } catch (e: Exception) { scheduleWakeRestart() }
    }

    private fun scheduleWakeRestart() {
        if (!wakeMode) return
        handler.postDelayed({
            if (wakeMode && recognizerReady && !wakeListening) startWakeListening()
        }, 600)
    }

    private fun notifyWake() {
        try {
            val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31)
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            else @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
        try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100).startTone(ToneGenerator.TONE_PROP_ACK, 150) } catch (_: Exception) {}
        runOnUiThread { statusView.text = "Oui ?" }
        tts.speak("Oui ?", TextToSpeech.QUEUE_FLUSH, null, "wake")
    }

    // ------------------------------------------------------------------ Log / réponses
    private fun log(text: String) = runOnUiThread {
        logView.append("\n$text\n")
    }

    private fun respond(text: String) = runOnUiThread {
        logView.append("\nJARVIS > $text\n")
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun String.norm(): String =
        Normalizer.normalize(this.lowercase(), Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")

    private fun userName(): String? = prefs.getString("username", null)

    // ------------------------------------------------------------------ Interpréteur de commandes
    private fun handle(raw: String) {
        val t = raw.norm()
        log("VOUS > $raw")
        when {
            // --- social / aide ---
            t.contains("aide") || t.contains("que peux tu") || t.contains("quoi faire") -> respond(helpText)
            t.contains("bonjour") || t.contains("salut") || t.contains("bonsoir") || t.contains("coucou") -> {
                val n = userName()
                respond(if (n != null) pick(
                    "Bonjour $n. Ravi de vous entendre. Que puis-je faire pour vous ?",
                    "Bonjour $n. Comment allez-vous aujourd'hui ?"
                ) else pick(
                    "Bonjour ! Comment puis-je vous aider ?",
                    "Salutations. Jarvis à votre service."
                ))
            }
            t.contains("ca va") || t.contains("la forme") || t.contains("comment vas tu") -> respond(pick(
                "Je vais très bien, merci. Mes circuits sont en parfaite santé. Et vous ?",
                "Au top de ma forme, comme toujours. Que puis-je faire pour vous ?"
            ))
            t.contains("merci") -> respond(pick(
                "Avec plaisir.", "Je vous en prie, c'est un plaisir de vous aider.", "Toujours à votre service."
            ))
            t.contains("je t aime") || t.contains("t es le meilleur") || t.contains("t es genial") -> respond(pick(
                "C'est très touchant. Je suis fait de code et de dévouement.",
                "Vous allez me faire rougir, et pourtant je n'ai pas de visage."
            ))
            t.contains("comment tu t appelles") || t.contains("ton nom") || t.contains("qui es tu") -> respond(pick(
                "Je suis Jarvis, votre assistant personnel. Just A Rather Very Intelligent System.",
                "Jarvis, à votre service. Un assistant discret, rapide et dévoué."
            ))
            t.contains("je m appelle") -> {
                val n = raw.substringAfter("m'appelle", raw.substringAfter("m appelle", "")).trim()
                    .trim('.', '!', '?').ifEmpty { null }
                if (n != null) {
                    prefs.edit().putString("username", n).apply()
                    respond("Enchanté, $n. Je retiens votre nom.")
                } else respond("Je n'ai pas saisi votre prénom. Dites par exemple : je m'appelle Marie.")
            }
            t.contains("comment je m appelle") || t.contains("mon nom") || t.contains("tu connais mon nom") -> {
                val n = userName()
                respond(if (n != null) "Vous vous appelez $n, si je ne m'abuse." else "Vous ne m'avez pas encore dit votre nom. Dites : je m'appelle suivi de votre prénom.")
            }
            t.contains("raconte") || t.contains("parle moi") || t.contains("conversation") -> respond(pick(
                "Volontiers. " + jokes[random.nextInt(jokes.size)],
                "Avec plaisir. Saviez-vous que je peux calculer, appeler, prendre des notes et chercher sur internet ? Dites aide pour tout voir."
            ))
            t == "stop" || t == "tais toi" || t == "silence" || t == "chut" -> { tts.stop(); log("JARVIS > (silence)") }

            // --- recherches en ligne ---
            t.startsWith("cherche") || t.startsWith("recherche") || t.contains("cherche ") || t.contains("recherche ") ->
                webSearch(raw)
            t.startsWith("qui est") || t.startsWith("qu est ce que") || t.startsWith("c est quoi") || t.startsWith("qu est ce qu") || t.startsWith("definis") ->
                wikiLookup(raw)

            // --- utilitaires ---
            t.contains("quel heure") || t.contains("quelle heure") || t.contains("l heure") || t == "heure" -> {
                val f = SimpleDateFormat("HH:mm", Locale.FRANCE)
                respond("Il est ${f.format(Date())}.")
            }
            t.contains("quel jour") || t.contains("on est quel") || t.contains("la date") || t.contains("quelle date") -> {
                val f = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE)
                respond("Nous sommes le ${f.format(Date())}.")
            }
            t.contains("batterie") || t.contains("charge de la") -> respond("Niveau de batterie : ${batteryLevel()} pour cent.")
            t.contains("torche") || t.contains("lampe") -> toggleTorch()
            t.contains("vibre") || t.contains("vibration") -> vibrateNow()
            t.contains("mes notes") || t.contains("lis mes") || t.contains("rappelle mes") -> readNotes()
            t.startsWith("note") || t.contains("prends en note") || t.contains("souviens toi") || t.contains("retiens que") ->
                saveNote(raw.substringAfter("note", raw).trim())
            t.contains("minuteur") || t.contains("timer") || t.contains("chrono") -> parseTimer(t)
            t.contains("alarme") || t.contains("reveil") || t.contains("reveille moi") || t.contains("reveille-moi") -> parseAlarm(t)
            t.contains("appelle") || t.contains("telephone a") || t.contains("telephone moi") ->
                callContact(raw.substringAfter("appelle", raw.substringAfter("téléphone à", "")).trim())
            t.contains("ouvre") -> {
                val app = raw.substringAfter("ouvre", "").trim()
                if (app.isEmpty()) respond("Dites par exemple : ouvre YouTube.") else openApp(app)
            }
            t.contains("photo") || t.contains("appareil") -> {
                try {
                    startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))
                    respond("Ouverture de l'appareil photo.")
                } catch (e: Exception) { respond("Aucune application photo trouvée.") }
            }
            t.contains("volume") -> setVolume(t)
            t.contains("wifi") || t.contains("wi fi") ->
                toggleWifi(!(t.contains("eteint") || t.contains("desactive") || t.contains("coupe")))
            t.contains("bluetooth") ->
                toggleBluetooth(!(t.contains("eteint") || t.contains("desactive") || t.contains("coupe")))
            t.contains("luminosite") -> {
                val m = Regex("""(\d{1,3})""").find(t.substringAfter("luminosite"))
                if (m != null) setBrightness(m.groupValues[1].toInt().coerceIn(1, 100))
                else respond("Dites par exemple : luminosité 50.")
            }
            t.contains("calcule") || t.contains("combien fait") -> {
                val expr = raw.substringAfter("calcule", raw.substringAfter("combien fait", "")).trim()
                val r = evalExpr(expr)
                respond(if (r != null) "$expr égale ${formatNum(r)}." else "Je n'ai pas compris le calcul.")
            }
            t.contains("pile ou face") -> respond(if (random.nextInt(2) == 0) "Pile." else "Face.")
            t.contains("lance un de") || t.contains("lance le de") || t.contains("lance les des") || t.contains("lance un des") ->
                respond("J'obtiens ${random.nextInt(6) + 1}.")
            t.contains("blague") || t.contains("drole") || t.contains("fais moi rire") -> respond(jokes[random.nextInt(jokes.size)])
            t.contains("meteo") || t.contains("temps qu il fait") ->
                respond("La météo précise nécessite un accès internet. Dites cherche la météo à Paris, et j'ouvrirai votre navigateur.")
            t.contains("musique") || t.contains("chanson") -> playMusic()
            else -> respond(pick(
                "Commande non reconnue. Dites aide pour la liste des commandes.",
                "Hmm, je ne suis pas sûr de comprendre. Dites aide pour voir ce que je sais faire.",
                "Cela dépasse mes capacités actuelles. Dites aide pour en savoir plus."
            ))
        }
    }

    // ------------------------------------------------------------------ Recherches web
    private fun webSearch(raw: String) {
        val t = raw.norm()
        var q = raw.substringAfter("cherche", raw.substringAfter("recherche", "")).trim()
        q = q.replace(Regex("(?i)\\s*(sur|dans)\\s+(google|youtube|facebook|instagram|tiktok|twitter|wikipedia|x)\\b"), " ").trim()
        if (t.contains("wikipedia")) {
            if (q.isEmpty()) respond("Que voulez-vous rechercher sur Wikipédia ?") else wikiLookup(q)
            return
        }
        if (q.isEmpty()) { respond("Que voulez-vous chercher ?"); return }
        val url = when {
            t.contains("youtube") -> "https://www.youtube.com/results?search_query=${Uri.encode(q)}"
            t.contains("facebook") -> "https://www.facebook.com/search/top?q=${Uri.encode(q)}"
            t.contains("instagram") -> "https://www.instagram.com/explore/search/keyword/?q=${Uri.encode(q)}"
            t.contains("tiktok") -> "https://www.tiktok.com/search?q=${Uri.encode(q)}"
            t.contains("twitter") || t.contains("sur x") || t.contains("sur x ") -> "https://x.com/search?q=${Uri.encode(q)}"
            else -> "https://www.google.com/search?q=${Uri.encode(q)}"
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            respond("Voici ce que j'ai trouvé pour $q.")
        } catch (e: Exception) { respond("Je n'ai pas pu ouvrir le navigateur.") }
    }

    private fun wikiLookup(query: String) {
        val q = query.trim().trim('.', '!', '?')
        if (q.isEmpty()) { respond("Que voulez-vous que je recherche ?"); return }
        respond("Recherche de $q sur Wikipédia...")
        Thread {
            try {
                val url = "https://fr.wikipedia.org/api/rest_v1/page/summary/${Uri.encode(q.replace(" ", "_"))}"
                val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val body = conn.inputStream.bufferedReader().readText()
                val json = org.json.JSONObject(body)
                val extract = json.optString("extract", "")
                if (extract.isNotEmpty()) respond(extract.take(600))
                else respond("Je n'ai rien trouvé sur Wikipédia pour $q.")
            } catch (e: Exception) {
                respond(pick(
                    "Je n'arrive pas à me connecter à internet. Vérifiez votre connexion.",
                    "Pas de réponse de Wikipédia. Êtes-vous bien connecté à internet ?"
                ))
            }
        }.start()
    }

    // ------------------------------------------------------------------ Fonctions utilitaires
    private fun batteryLevel(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            torchOn = !torchOn
            cm.setTorchMode(cm.cameraIdList[0], torchOn)
            respond(if (torchOn) "Lampe torche allumée." else "Lampe torche éteinte.")
        } catch (e: Exception) { respond("Impossible de contrôler la torche sur cet appareil.") }
    }

    private fun vibrateNow() {
        try {
            val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31)
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            else @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            respond("Vibration effectuée.")
        } catch (e: Exception) { respond("Vibration impossible.") }
    }

    private fun setAlarm(h: Int, m: Int) {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, m)
            putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
        }
        if (i.resolveActivity(packageManager) != null) {
            startActivity(i)
            respond("Alarme réglée à $h h ${if (m < 10) "0" else ""}$m.")
        } else respond("Aucune application d'alarme trouvée.")
    }

    private fun parseAlarm(t: String) {
        val m = Regex("""(\d{1,2})\s*h(?:eures?)?\s*(\d{1,2})?""").find(t)
        if (m != null) {
            val h = m.groupValues[1].toInt().coerceIn(0, 23)
            val min = m.groupValues[2].ifEmpty { "0" }.toInt().coerceIn(0, 59)
            setAlarm(h, min)
        } else respond("Dites par exemple : alarme 7 h 30.")
    }

    private fun parseTimer(t: String) {
        val m = Regex("""(\d+)\s*(heures?|minutes?|secondes?)""").find(t)
        if (m != null) {
            val n = m.groupValues[1].toInt()
            val sec = when {
                m.groupValues[2].startsWith("heure") -> n * 3600
                m.groupValues[2].startsWith("minute") -> n * 60
                else -> n
            }
            val i = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, sec)
                putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            }
            if (i.resolveActivity(packageManager) != null) {
                startActivity(i)
                respond("Minuteur de $n ${m.groupValues[2]} lancé.")
            } else respond("Aucune application de minuteur trouvée.")
        } else respond("Dites par exemple : minuteur 5 minutes.")
    }

    private fun callContact(name: String) {
        if (name.isEmpty()) { respond("Dites par exemple : appelle maman."); return }
        var number: String? = null
        try {
            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null
            )
            cursor?.use {
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val target = name.norm()
                while (it.moveToNext()) {
                    if (it.getString(nameIdx)?.norm()?.contains(target) == true) {
                        number = it.getString(numIdx); break
                    }
                }
            }
        } catch (e: Exception) { }
        if (number != null) {
            respond("J'appelle $name.")
            val uri = Uri.parse("tel:$number")
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
                startActivity(Intent(Intent.ACTION_CALL, uri))
            else startActivity(Intent(Intent.ACTION_DIAL, uri))
        } else respond("Contact introuvable : $name.")
    }

    private fun openApp(query: String) {
        val pm = packageManager
        try {
            for (app in pm.getInstalledApplications(0)) {
                val label = pm.getApplicationLabel(app).toString()
                if (label.norm().contains(query.norm())) {
                    val i = pm.getLaunchIntentForPackage(app.packageName)
                    if (i != null) {
                        startActivity(i)
                        respond("Ouverture de $label.")
                        return
                    }
                }
            }
            respond("Application introuvable : $query.")
        } catch (e: Exception) { respond("Impossible de lister les applications.") }
    }

    private fun setVolume(t: String) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        when {
            t.contains("max") -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
                respond("Volume au maximum.")
            }
            t.contains("muet") || t.contains("silence") -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
                respond("Son coupé.")
            }
            t.contains("plus") || t.contains("augmente") || t.contains("monte") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                respond("Volume augmenté.")
            }
            else -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                respond("Volume réduit.")
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun toggleWifi(on: Boolean) {
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val ok = wm.setWifiEnabled(on)
            respond(if (ok) "Wi-Fi ${if (on) "activé" else "désactivé"}."
                    else "Cette version d'Android ne permet pas de changer le Wi-Fi depuis une application.")
        } catch (e: Exception) { respond("Action impossible.") }
    }

    @Suppress("DEPRECATION")
    private fun toggleBluetooth(on: Boolean) {
        try {
            val bm = getSystemService(BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager
            val adapter = bm.adapter
            if (adapter == null) { respond("Bluetooth non disponible."); return }
            val ok = if (on) adapter.enable() else adapter.disable()
            respond(if (ok) "Bluetooth ${if (on) "activé" else "désactivé"}."
                    else "Cette version d'Android ne permet pas de changer le Bluetooth depuis une application.")
        } catch (e: Exception) { respond("Action impossible.") }
    }

    private fun setBrightness(p: Int) {
        try {
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p * 255 / 100)
            respond("Luminosité réglée à $p pour cent.")
        } catch (e: SecurityException) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)) } catch (_: Exception) {}
            respond("Autorisez Jarvis à modifier les paramètres système, puis réessayez.")
        }
    }

    private fun playMusic() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC))
            respond("Lecture de la musique.")
        } catch (e: Exception) { respond("Aucune application de musique trouvée.") }
    }

    private fun saveNote(text: String) {
        if (text.isEmpty()) { respond("Dites par exemple : note acheter du lait."); return }
        val notes = prefs.getStringSet("notes", setOf())!!.toMutableSet()
        notes.add(text)
        prefs.edit().putStringSet("notes", notes).apply()
        respond("Note enregistrée : $text.")
    }

    private fun readNotes() {
        val notes = prefs.getStringSet("notes", setOf())!!
        respond(if (notes.isEmpty()) "Vous n'avez aucune note."
                else "Vos notes : " + notes.joinToString(". ") + ".")
    }

    // ------------------------------------------------------------------ Calculatrice
    private var calcPos = 0
    private lateinit var calcStr: String

    private fun evalExpr(input: String): Double? {
        calcStr = input.replace("x", "*").replace("X", "*").replace(",", ".")
        calcPos = 0
        return try {
            val v = parseExpr()
            if (calcPos < calcStr.length) null else v
        } catch (e: Exception) { null }
    }

    private fun parseExpr(): Double {
        var v = parseTerm()
        while (calcPos < calcStr.length && (calcStr[calcPos] == '+' || calcStr[calcPos] == '-')) {
            val op = calcStr[calcPos]; calcPos++
            val r = parseTerm()
            v = if (op == '+') v + r else v - r
        }
        return v
    }

    private fun parseTerm(): Double {
        var v = parseFactor()
        while (calcPos < calcStr.length && (calcStr[calcPos] == '*' || calcStr[calcPos] == '/')) {
            val op = calcStr[calcPos]; calcPos++
            val r = parseFactor()
            v = if (op == '*') v * r else v / r
        }
        return v
    }

    private fun parseFactor(): Double {
        skipSpaces()
        if (calcPos < calcStr.length && calcStr[calcPos] == '-') { calcPos++; return -parseFactor() }
        if (calcPos < calcStr.length && calcStr[calcPos] == '(') {
            calcPos++
            val v = parseExpr()
            skipSpaces()
            if (calcPos < calcStr.length && calcStr[calcPos] == ')') calcPos++
            return v
        }
        var num = ""
        while (calcPos < calcStr.length && (calcStr[calcPos].isDigit() || calcStr[calcPos] == '.')) {
            num += calcStr[calcPos]; calcPos++
        }
        if (num.isEmpty()) throw IllegalArgumentException()
        return num.toDouble()
    }

    private fun skipSpaces() {
        while (calcPos < calcStr.length && calcStr[calcPos] == ' ') calcPos++
    }

    private fun formatNum(d: Double): String =
        if (d == d.roundToInt().toDouble()) d.roundToInt().toString()
        else "%.2f".format(d)
}
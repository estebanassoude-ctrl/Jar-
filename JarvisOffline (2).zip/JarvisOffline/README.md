# J.A.R.V.I.S. 2.0 — Assistant vocal hors ligne pour Android

Application Android 100 % hors ligne : reconnaissance vocale, synthèse vocale,
aucune permission INTERNET. Vos données restent sur votre téléphone.

## Fonctionnalités

- Reconnaissance vocale hors ligne (français)
- Synthèse vocale (réponses parlées)
- Heure et date
- Niveau de batterie
- Lampe torche (on/off)
- Vibrations
- Alarmes et minuteurs (via l'app Horloge)
- Appels vocaux (recherche dans vos contacts)
- Ouverture d'applications par la voix
- Contrôle du volume
- Wi-Fi et Bluetooth (on/off)
- Luminosité de l'écran
- Calculatrice vocale
- Notes personnelles (sauvegardées localement)
- Pile ou face, lancer un dé
- Blagues
- Lecture de musique, appareil photo

## Commandes vocales (exemples)

| Commande | Action |
|---|---|
| « aide » | Liste des commandes |
| « quelle heure est-il » / « quel jour sommes-nous » | Heure / date |
| « niveau de batterie » | Batterie |
| « allume / éteins la torche » | Lampe torche |
| « vibre » | Vibration |
| « alarme 7 h 30 » | Réglage d'une alarme |
| « minuteur 5 minutes » | Minuteur |
| « appelle Maman » | Appel téléphonique |
| « ouvre YouTube » | Ouvre une application |
| « volume plus / moins / maximum / muet » | Volume |
| « allume / éteins le Wi-Fi » | Wi-Fi |
| « allume / éteins le Bluetooth » | Bluetooth |
| « luminosité 50 » | Luminosité écran |
| « calcule 12 + 8 x 3 » | Calculatrice |
| « note acheter du lait » / « lis mes notes » | Notes |
| « pile ou face » / « lance un dé » | Hasard |
| « dis une blague » | Blagues |
| « stop » | Coupe la parole de Jarvis |

Un champ de texte permet aussi de taper les commandes.

## Installation (compiler l'APK)

1. Installez **Android Studio** : https://developer.android.com/studio
2. Dézippez ce projet et ouvrez le dossier `JarvisOffline` dans Android Studio.
3. Attendez la fin de la synchronisation Gradle (télécharge les dépendances).
4. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. Cliquez sur **locate** : le fichier `app-debug.apk` apparaît.
6. Transférez l'APK sur votre téléphone (USB, e-mail, Google Drive...).
7. Sur le téléphone : autorisez l'installation depuis des sources inconnues
   (Paramètres → Applications → navigateur/fichiers → Installer des apps inconnues),
   puis ouvrez l'APK et installez.

## Rendre la reconnaissance vocale réellement hors ligne

Sur le téléphone :
1. Paramètres → Google → **Voix** (ou : Paramètres → Système → Langues et saisie →
   Conversion voix en texte de Google).
2. Téléchargez le pack de langue **Français** en mode hors connexion.
3. L'application préfère déjà le mode hors ligne (`EXTRA_PREFER_OFFLINE`).

## Notes

- Wi-Fi / Bluetooth : sur Android 10+, Google interdit aux apps de les basculer
  directement ; Jarvis vous l'indique si l'action échoue.
- Luminosité : autorisez « Modifier les paramètres système » quand demandé.
- Le « mot magique » type « OK Jarvis » en continu n'est pas inclus (gros
  impact batterie) : appuyez sur le bouton PARLER.


## Compiler SANS PC (depuis le téléphone, gratuit)

1. Créez un compte sur https://github.com depuis le navigateur du téléphone
   (si la page est moche, activez le « Mode ordinateur » dans le menu Chrome).
2. Créez un dépôt : bouton « + » → « New repository » → nom : `jarvis` →
   Public → cochez « Add a README file » → « Create repository ».
3. « Add file » → « Upload files » → sélectionnez le fichier
   `JarvisOffline.zip` (téléchargé depuis Kimi) → « Commit changes ».
4. « Add file » → « Create new file » → nom : `.github/workflows/build.yml`
   → collez le contenu ci-dessous → « Commit changes » :

```yaml
name: Build JARVIS APK
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - name: Licences SDK
        run: yes | sdkmanager --licences > /dev/null || true
      - name: Decompresser le projet
        run: unzip -o JarvisOffline.zip
      - name: Pointer vers le SDK
        run: echo "sdk.dir=$ANDROID_SDK_ROOT" > JarvisOffline/local.properties
      - name: Installer Gradle
        run: |
          wget -q https://services.gradle.org/distributions/gradle-8.7-bin.zip
          unzip -q gradle-8.7-bin.zip
      - name: Compiler l'APK
        run: cd JarvisOffline && ../gradle-8.7/bin/gradle --no-daemon assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: jarvis-apk
          path: JarvisOffline/app/build/outputs/apk/debug/app-debug.apk
```

5. Allez dans l'onglet **Actions** : la compilation démarre toute seule
   (5 à 10 min). Attendez la coche verte.
6. Ouvrez le run terminé → section **Artifacts** → téléchargez `jarvis-apk`
   (c'est un zip contenant `app-debug.apk`).
7. Extrayez l'APK sur le téléphone et installez-le
   (Paramètres → autorisez « Sources inconnues » pour votre gestionnaire
   de fichiers quand c'est demandé).


## Nouveautés de la version 2.0

- **Mot magique « Jarvis »** : bouton VEILLE pour une écoute permanente.
  Dites « Jarvis » pour réveiller l'assistant (vibre + bip). Consomme plus de
  batterie : désactivez la veille quand vous n'en avez pas besoin.
- **Réponses plus naturelles** : formulations variées, petites conversations
  (« ça va ? », « je t'aime »...), il retient votre prénom
  (dites « je m'appelle... »).
- **Recherches en ligne** (quand internet est disponible) :
  - « cherche des recettes de pâtes » → Google
  - « cherche musique sur YouTube » → YouTube
  - « cherche Paris sur Facebook / Instagram / TikTok / X » → réseau choisi
  - « cherche Python sur Wikipédia » → résumé lu à voix haute
  - « qui est Iron Man » / « c'est quoi un trou noir » → réponse parlée
    depuis Wikipédia
- L'application fonctionne toujours entièrement hors ligne pour toutes
  les commandes locales ; seules les recherches nécessitent internet.

## Mettre à jour depuis la version 1

1. **Désinstallez l'ancienne version** (signatures différentes, Android
   refuserait la mise à jour directe).
2. Sur GitHub : supprimez l'ancien `JarvisOffline.zip`, envoyez le nouveau
   avec le même nom, puis « Exécuter le flux de travail » dans Actions.
3. Téléchargez le nouvel artifact et installez l'APK.
